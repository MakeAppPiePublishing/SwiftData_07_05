//
//  HPMigrationPlan.swift
//  HuliPizzaPersistent
//
//  Created by Steven Lipton on 2/13/24.
//

import Foundation
import SwiftData

enum HPMigrationPlan: SchemaMigrationPlan{
    static var schemas: [VersionedSchema.Type]{
        [HPSchemaV01_00_00.self,
         HPSchemaV01_01_00.self,
         HPSchemaV02_00_00.self]
    }
    
    static var migrateV01_00_00to01_01_00:MigrationStage{
        MigrationStage.lightweight(fromVersion: HPSchemaV01_00_00.self, toVersion: HPSchemaV01_01_00.self)
    }
    static var migrateV01_01_00to02_00_00:MigrationStage{
        MigrationStage.lightweight(fromVersion: HPSchemaV01_01_00.self, toVersion: HPSchemaV02_00_00.self)
    }
    static var stages: [MigrationStage]{
        [migrateV01_00_00to01_01_00,
        migrateV01_01_00to02_00_00]
    }
    
    
}
